@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText('%~f0',[Text.Encoding]::UTF8);$m='#'+'CUTAI_PS1';$i=$s.LastIndexOf($m);$p=Join-Path $env:TEMP 'CutAI-install.ps1';[IO.File]::WriteAllText($p,$s.Substring($i+$m.Length),(New-Object Text.UTF8Encoding $true));& $p"
echo.
pause
exit /b
#CUTAI_PS1
# ติดตั้ง / ซ่อม โปรแกรมตัดคลิป AI บน Windows 10/11
# ดับเบิลคลิก ติดตั้งโปรแกรม.bat (ไม่ต้องเปิดไฟล์นี้เอง) — รันซ้ำได้เรื่อย ๆ ถ้ามีอะไรพัง (ของที่มีแล้วจะข้าม)
#
# ทำอะไรบ้าง:
#  1) วิเคราะห์เครื่อง (Windows / RAM / การ์ดจอ / พื้นที่ดิสก์)
#  2) ติดตั้ง Git, Python 3.12, FFmpeg ผ่าน winget (ตัวติดตั้งของ Windows เอง)
#  3) ดึงโปรแกรมจาก GitHub สาย stable ไว้ที่ C:\Users\<ชื่อ>\CutAI  (ครั้งแรกจะมีหน้าต่างให้ล็อกอิน GitHub)
#  4) ติดตั้งไลบรารี Python + โหลดตัวถอดเสียงในเครื่อง (~1.5 GB ครั้งเดียว)
#  5) ตรวจเครื่องมือ + เลือกตัวเข้ารหัสวิดีโอตามการ์ดจอ
#  6) สร้างไอคอน "ตัดคลิป AI" บน Desktop  7) เปิดโปรแกรม
# หลังจากนี้ทุกครั้งที่เปิดโปรแกรม จะเช็ค GitHub แล้วอัปเดตเป็นรุ่นล่าสุดให้เอง (อัปเดตแล้วเปิดไม่ขึ้น = ถอยกลับรุ่นเดิมเอง)
# ข้อมูลของโปรแกรม (คีย์/ตั้งค่า/log): เครื่องที่เคยติดตั้งแล้วอยู่ที่ CutAI\งาน เหมือนเดิม · เครื่องใหม่อยู่ที่ %LOCALAPPDATA%\CutAI\งาน

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"         # แถบความคืบหน้าของ PowerShell 5.1 ทำให้ดาวน์โหลด/แตก zip ช้าลงหลายเท่า
# ติดตั้งแบบลูกค้า: ระบบขายใส่ 2 ค่านี้ให้ตอนลูกค้าดาวน์โหลดตัวติดตั้ง (ระบบขาย/README.md) — ว่าง = ติดตั้งแบบเจ้าของจาก GitHub
$CutAIServer = "https://script.google.com/macros/s/AKfycbx_UXwvru_VdhzTwgCq0w5CE_eRKxj69EZapGD97R1_ypurfpgY1r0zTb16HHKXlbalDQ/exec"
$CutAIKey = ""
$Customer = ($CutAIServer -ne "")                 # มี server แต่คีย์ว่าง = ตัวติดตั้งสาธารณะ (ลิงก์ตรงบนหน้าขาย) → ดึงรุ่นผ่าน manifest_public ไม่ใช้ GitHub
$Repo   = "https://github.com/sahaphakhun/cut-clip-ai.git"
$Branch = "stable"
$Dest   = Join-Path $env:USERPROFILE "CutAI"
if ($env:CUTAI_DEST) { $Dest = $env:CUTAI_DEST }   # ทดสอบเท่านั้น: ลงโฟลเดอร์อื่น ไม่ทับโปรแกรมจริง (คู่กับ CUTAI_DATA / CUTAI_DESKTOP)

$script:StepNo = 0                                 # ขั้นที่กำลังทำ (จาก Say "N/7 …") — ใช้บอกลูกค้าว่าล้มที่ขั้นไหน
$script:StepTitle = ""
$script:InstallLogPath = Join-Path $env:TEMP "CutAI_ติดตั้ง_error.txt"   # ไฟล์ log เดียวกับตอนดึง manifest
function Say($m)  {
    if ($m -match '^([1-7])/7 (.+)$') { $script:StepNo = [int]$Matches[1]; $script:StepTitle = $Matches[2] }
    Write-Host "`n== $m ==" -ForegroundColor Cyan
}
function Ok($m)   { Write-Host "  [OK] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "  [!]  $m" -ForegroundColor Yellow }
function Fail($m) { Stop-CutAIInstall -Reason $m }   # บอกขั้นที่ล้ม + วิธีแก้ + ถามส่งรายงาน แล้วจบ (ดูด้านล่าง)
function Refresh-Path {
    $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" +
                [Environment]::GetEnvironmentVariable("Path", "User") + ";" +
                (Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links")
}
function Winget-Install($id, $extra) {
    $wargs = @("install", "--id", $id, "-e", "--silent", "--accept-package-agreements", "--accept-source-agreements") + $extra
    & winget @wargs
    if ($LASTEXITCODE -ne 0 -and $LASTEXITCODE -ne -1978335189) {   # -1978335189 = ติดตั้งไว้แล้ว
        Warn "winget $id จบด้วยรหัส $LASTEXITCODE (จะตรวจซ้ำอีกที)"
    }
    Refresh-Path
}

# ───────── ดึง manifest จากระบบขาย (ฟังก์ชันแยก ทดสอบได้โดยไม่ยิงเน็ตจริง — ดู tests/test_install_windows.ps1) ─────────
function Set-CutAITlsProtocols {
    # บางเครื่อง .NET เก่าไม่มี enum Tls13 เลย → ต้องแยก try ของ Tls12/Tls13 คนละก้อน ไม่ให้ตัวที่ไม่มีทำตัวที่มีพังไปด้วย
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls13 } catch { }
}

function Get-CutAIProxyUri {
    param([Parameter(Mandatory=$true)][string]$TargetUrl)
    try {
        $sysProxy = [System.Net.WebRequest]::GetSystemWebProxy()
        $targetUri = [uri]$TargetUrl
        if ($sysProxy.IsBypassed($targetUri)) { return $null }
        $proxyUri = $sysProxy.GetProxy($targetUri)
        if ($proxyUri -and $proxyUri.AbsoluteUri -ne $targetUri.AbsoluteUri) { return $proxyUri }
    } catch { }
    return $null
}

# แยกสาเหตุจาก exception ให้อ่านรู้เรื่อง — ไม่ใช่แค่ "ติดต่อไม่ได้" ลอย ๆ
function Get-CutAIErrorReason {
    param($Exception)
    if ($Exception -is [System.Net.WebException]) {
        try {
            if ($Exception.Response -and $Exception.Response.StatusCode) {
                return "เซิร์ฟเวอร์ตอบรหัส HTTP $([int]$Exception.Response.StatusCode) ($($Exception.Response.StatusCode))"
            }
        } catch { }
        switch ($Exception.Status) {
            ([System.Net.WebExceptionStatus]::NameResolutionFailure)      { return "หา DNS ของระบบขายไม่เจอ (NameResolutionFailure)" }
            ([System.Net.WebExceptionStatus]::ConnectFailure)             { return "เชื่อมต่อปลายทางไม่ได้ (ConnectFailure — ไฟร์วอลล์/VPN/แอนตี้ไวรัสอาจบล็อกอยู่)" }
            ([System.Net.WebExceptionStatus]::Timeout)                   { return "เชื่อมต่อหมดเวลา (Timeout — เน็ตช้าหรือปลายทางไม่ตอบ)" }
            ([System.Net.WebExceptionStatus]::TrustFailure)              { return "ปัญหา TLS/SSL (TrustFailure — ใบรับรองไม่ผ่าน)" }
            ([System.Net.WebExceptionStatus]::SecureChannelFailure)      { return "ปัญหา TLS/SSL (SecureChannelFailure — เปิดช่องทางปลอดภัยไม่ได้)" }
            ([System.Net.WebExceptionStatus]::ProxyNameResolutionFailure) { return "หา proxy ของเครื่องนี้ไม่เจอ (ProxyNameResolutionFailure)" }
            default { return "$($Exception.Status) — $($Exception.Message)" }
        }
    }
    return "$($Exception.GetType().Name): $($Exception.Message)"
}

function Write-CutAIInstallLog {
    param(
        [Parameter(Mandatory=$true)][string]$LogPath,
        [Parameter(Mandatory=$true)][string]$Message
    )
    try {
        $line = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $Message"
        Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
    } catch { }
}

# ลอง Invoke-RestMethod 3 ครั้ง (TLS12/13 + system proxy) แล้วค่อยลองสำรองด้วย curl.exe — เก็บ log ทุกครั้งให้ลูกค้าคัดลอกส่งได้
function Get-CutAIManifest {
    param(
        [Parameter(Mandatory=$true)][string]$ManifestUrl,
        [string]$LogPath = (Join-Path $env:TEMP "CutAI_ติดตั้ง_error.txt"),
        [int[]]$RetryDelaySec = @(3, 6, 10),
        [scriptblock]$RequestScript = {
            param($Uri, $ProxyUri)
            $irmArgs = @{ Uri = $Uri; UseBasicParsing = $true; TimeoutSec = 90 }
            if ($ProxyUri) { $irmArgs["Proxy"] = $ProxyUri.AbsoluteUri; $irmArgs["ProxyUseDefaultCredentials"] = $true }
            Invoke-RestMethod @irmArgs
        },
        [scriptblock]$CurlScript = {
            param($Uri)
            $out = & curl.exe -s -m 30 $Uri 2>&1
            if ($LASTEXITCODE -ne 0 -or -not $out) { throw "curl.exe คืนรหัส $LASTEXITCODE หรือไม่มีผลลัพธ์" }
            ($out | Out-String) | ConvertFrom-Json
        }
    )
    Set-CutAITlsProtocols
    $proxyUri = Get-CutAIProxyUri -TargetUrl $ManifestUrl
    $tries = 3
    $lastReason = $null
    for ($i = 1; $i -le $tries; $i++) {
        try {
            $result = & $RequestScript $ManifestUrl $proxyUri
            return [pscustomobject]@{ Ok = $true; Manifest = $result; Reason = $null; LogPath = $LogPath }
        } catch {
            $lastReason = Get-CutAIErrorReason -Exception $_.Exception
            Write-CutAIInstallLog -LogPath $LogPath -Message "เรียก manifest ครั้งที่ $i/$tries ล้มเหลว: $lastReason | $($_.Exception.ToString())"
            if ($i -le $RetryDelaySec.Count) { Start-Sleep -Seconds $RetryDelaySec[$i - 1] }
        }
    }
    try {
        $result = & $CurlScript $ManifestUrl
        Write-CutAIInstallLog -LogPath $LogPath -Message "ลอง curl.exe สำรองสำเร็จ"
        return [pscustomobject]@{ Ok = $true; Manifest = $result; Reason = $null; LogPath = $LogPath }
    } catch {
        $curlReason = Get-CutAIErrorReason -Exception $_.Exception
        Write-CutAIInstallLog -LogPath $LogPath -Message "curl.exe สำรองล้มเหลว: $curlReason | $($_.Exception.ToString())"
        if (-not $lastReason) { $lastReason = $curlReason }
        return [pscustomobject]@{ Ok = $false; Manifest = $null; Reason = $lastReason; LogPath = $LogPath }
    }
}

# ───────── ติดตั้งล้ม: บอกขั้นที่ล้ม + วิธีแก้ + ปุ่มส่งรายงานอาการ (ไม่ส่งคีย์/ชื่อ/ข้อมูลส่วนตัว) ─────────
# วิธีแก้แยกตามขั้น 1-7 (ภาษาคนทั่วไป) · ขั้น 0 = ล้มก่อนเริ่ม/ไม่รู้ขั้น
function Get-CutAIStepAdvice {
    param([int]$Step)
    switch ($Step) {
        1 { return @("เครื่องนี้ไม่มี winget (ตัวติดตั้งโปรแกรมของ Windows) — เปิด Microsoft Store ค้นหา 'App Installer' กดติดตั้ง/อัปเดต แล้วดับเบิลคลิกตัวติดตั้งใหม่",
                     "ถ้าเป็น Windows 10 รุ่นเก่ามาก ให้ทำ Windows Update ก่อน") }
        2 { return @("ติดตั้งเครื่องมือ (Python / FFmpeg) ไม่สำเร็จ — ปิด VPN และปิดโปรแกรมแอนตี้ไวรัสชั่วคราว แล้วดับเบิลคลิกตัวติดตั้งใหม่ (ของที่ลงไปแล้วจะข้าม ไม่ลงซ้ำ)",
                     "เช็คว่าไดรฟ์ C: ยังมีที่ว่างอย่างน้อย 10 GB",
                     "ถ้ามีหน้าต่างขอสิทธิ์ของ Windows เด้งขึ้นมา ให้กด 'ใช่/Yes'") }
        3 { return @("ดาวน์โหลดโปรแกรมไม่สำเร็จ — ส่วนใหญ่เป็นเพราะเน็ตหลุด/VPN/ไฟร์วอลล์/แอนตี้ไวรัสบล็อก ลองปิดตัวบล็อกชั่วคราวแล้วดับเบิลคลิกตัวติดตั้งใหม่",
                     "เช็คว่าไดรฟ์ C: มีที่ว่างพอ และเปิดเว็บทั่วไปได้ตามปกติ") }
        4 { return @("ติดตั้งส่วนประกอบของโปรแกรม (ไลบรารี Python) ไม่สำเร็จ — ส่วนใหญ่เน็ตหลุดกลางทาง ให้ดับเบิลคลิกตัวติดตั้งใหม่ (โหลดต่อจากเดิม)",
                     "ถ้าใช้เน็ตบริษัท/โรงเรียน อาจมี proxy บล็อก ลองใช้ฮอตสปอตมือถือแทน") }
        5 { return @("ตรวจเครื่องมือของโปรแกรมไม่ผ่าน — ดับเบิลคลิกตัวติดตั้งใหม่อีกครั้ง (ใช้เวลาไม่นาน)",
                     "ถ้ายังไม่ผ่าน ให้ส่งรายงานด้านล่าง ทีมงานจะดูให้") }
        6 { return @("สร้างไอคอนบน Desktop ไม่สำเร็จ แต่โปรแกรมลงเสร็จแล้ว — เปิดได้จากโฟลเดอร์ CutAI ในโฟลเดอร์ผู้ใช้ ดับเบิลคลิก launcher.py") }
        7 { return @("เปิดโปรแกรมไม่ขึ้น — ลองดับเบิลคลิกไอคอน 'ตัดคลิป AI' บน Desktop อีกครั้ง หรือรีสตาร์ตเครื่องแล้วเปิดใหม่",
                     "ถ้ามีหน้าต่างไฟร์วอลล์ถามสิทธิ์ ให้กดอนุญาต") }
    }
    return @("ลองดับเบิลคลิกตัวติดตั้งใหม่อีกครั้ง (ของที่ลงไปแล้วจะข้าม)",
             "ถ้ายังไม่ได้ ให้ส่งรายงานด้านล่าง หรือส่งไฟล์ log ให้แอดมินทางไลน์")
}

# ลบข้อมูลส่วนตัวออกจากข้อความก่อนแสดง/ส่ง: คีย์ · token/รหัสในลิงก์ · ลิงก์ระบบขาย · อีเมล · ชื่อผู้ใช้/ชื่อเครื่อง
function Protect-CutAIText {
    param([string]$Text)
    if (-not $Text) { return "" }
    $t = $Text
    foreach ($secret in @($CutAIKey, $CutAIServer)) {
        if ($secret -and $secret.Length -ge 4) { $t = $t.Replace($secret, "***") }
    }
    $t = [regex]::Replace($t, '(?i)\b(key|token|order|admin|code)=[^&\s"'']+', '$1=***')
    $t = [regex]::Replace($t, '(?i)https?://script\.google(usercontent)?\.com/\S+', '<ลิงก์ระบบขาย>')
    $t = [regex]::Replace($t, '[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)+', '<อีเมล>')
    foreach ($pair in @(@($env:USERPROFILE, "<โฟลเดอร์ผู้ใช้>"), @($env:USERNAME, "<ผู้ใช้>"), @($env:COMPUTERNAME, "<เครื่อง>"))) {
        if ($pair[0] -and $pair[0].Length -ge 3) { $t = [regex]::Replace($t, [regex]::Escape($pair[0]), $pair[1], "IgnoreCase") }
    }
    return $t
}

function Get-CutAIEnvSummary {
    $o = @()
    try {
        $os = Get-CimInstance Win32_OperatingSystem
        $o += "Windows: $($os.Caption) ($($os.Version))"
        $o += "RAM: $([math]::Round($os.TotalVisibleMemorySize / 1MB, 1)) GB"
    } catch { $o += "Windows: อ่านไม่ได้" }
    try { $o += "PowerShell: $($PSVersionTable.PSVersion)" } catch { }
    try { $o += "ดิสก์ว่าง: $([math]::Round((Get-PSDrive ($env:USERPROFILE.Substring(0,1))).Free / 1GB, 0)) GB" } catch { }
    try { $o += "winget: " + $(if (Get-Command winget -ErrorAction SilentlyContinue) { "มี" } else { "ไม่มี" }) } catch { }
    try { $o += "สิทธิ์ผู้ดูแล: " + ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } catch { }
    return ($o -join "`n")
}

# ข้อความรายงานอาการ (ลบข้อมูลส่วนตัวแล้ว) — ขั้นที่ล้ม + สาเหตุ + เครื่อง + ท้ายไฟล์ log
function New-CutAIFailReport {
    param([int]$Step, [string]$Title, [string]$Reason, [string]$LogPath = $script:InstallLogPath, [string]$EnvSummary = $null)
    if ($null -eq $EnvSummary) { $EnvSummary = Get-CutAIEnvSummary }
    $tail = ""
    try { if ($LogPath -and (Test-Path -LiteralPath $LogPath)) { $tail = (Get-Content -LiteralPath $LogPath -Tail 25 -Encoding UTF8 -ErrorAction Stop) -join "`n" } } catch { }
    $text = "[ตัวติดตั้ง Windows ล้ม] ขั้น $Step/7 $Title`nสาเหตุ: $Reason`n`n$EnvSummary"
    if ($tail) { $text += "`n`n--- ท้ายไฟล์ log ---`n$tail" }
    return Protect-CutAIText $text
}

# ส่งรายงานเข้าฟีดแบ็กของระบบขาย (action install_report — ไม่ต้องมีคีย์ ไม่แนบคีย์) · ไม่มีช่องทาง/ส่งไม่ได้ = คืน Ok=$false พร้อมเหตุผล ไม่ throw
function Send-CutAIInstallReport {
    param(
        [Parameter(Mandatory=$true)][string]$Text,
        [string]$Contact = "",
        [int]$Step = 0,
        [string]$Server = $CutAIServer,
        [scriptblock]$PostScript = {
            param($Uri, $Bytes)
            Invoke-RestMethod -Uri $Uri -Method Post -Body $Bytes -ContentType "text/plain; charset=utf-8" -UseBasicParsing -TimeoutSec 60
        }
    )
    if (-not $Server) { return [pscustomobject]@{ Ok = $false; Reason = "ตัวติดตั้งนี้ไม่มีช่องส่งรายงาน" } }
    try {
        Set-CutAITlsProtocols
        $body = [ordered]@{
            action  = "install_report"
            os      = "win"
            step    = "$Step/7"
            text    = (Protect-CutAIText $Text)
            contact = (Protect-CutAIText $Contact)
            cid     = ("ins-" + [guid]::NewGuid().ToString("N").Substring(0, 12))
        } | ConvertTo-Json -Compress
        $bytes = [Text.Encoding]::UTF8.GetBytes($body)
        $r = & $PostScript $Server $bytes
        if ($r -and $r.ok) { return [pscustomobject]@{ Ok = $true; Reason = ""; Id = "$($r.id)" } }
        $why = "ระบบขายไม่รับรายงาน"
        if ($r -and $r.error) { $why = "$($r.error)" }
        return [pscustomobject]@{ Ok = $false; Reason = $why }
    } catch {
        return [pscustomobject]@{ Ok = $false; Reason = (Get-CutAIErrorReason -Exception $_.Exception) }
    }
}

# ✅ ติดตั้งเสร็จจริง → บอกระบบขายครั้งเดียว (action install_done = นับ "ติดตั้งสำเร็จ" ในแดชบอร์ด)
# ไม่ส่งคีย์/ชื่อ/ข้อมูลเครื่อง · ยิงไม่ติดแค่จด log แล้วคืน $false — ไม่ throw ไม่ทำให้การติดตั้งล้ม
function Send-CutAIInstallDone {
    param(
        [string]$Server = $CutAIServer,
        [scriptblock]$GetScript = {
            param($Uri)
            Invoke-RestMethod -Uri $Uri -UseBasicParsing -TimeoutSec 15 | Out-Null
        }
    )
    if (-not $Server) { return $false }
    try {
        Set-CutAITlsProtocols
        $sep = "?"
        if ($Server.Contains("?")) { $sep = "&" }
        & $GetScript ($Server + $sep + "action=install_done&os=win")
        return $true
    } catch {
        try { Write-CutAIInstallLog -LogPath $script:InstallLogPath -Message ("แจ้งระบบขายว่าติดตั้งสำเร็จไม่ติด (ไม่กระทบการติดตั้ง): " + (Protect-CutAIText (Get-CutAIErrorReason -Exception $_.Exception))) } catch { }
        return $false
    }
}

# ติดตั้งล้ม: บอกขั้น + สาเหตุ + วิธีแก้ → จดไฟล์ log → ถามว่าจะส่งรายงานไหม → จบ (exit 1)
# $env:CUTAI_NO_REPORT=1 หรือ $env:CUTAI_INSTALL_TEST_FUNCS (ทดสอบ) = ไม่ถามอะไร ไม่ส่งอะไร
function Stop-CutAIInstall {
    param([string]$Reason, [switch]$NoExit)
    $step = $script:StepNo
    Write-Host ""
    Write-Host "[X] ติดตั้งไม่สำเร็จ — ล้มที่ขั้น $step/7 : $($script:StepTitle)" -ForegroundColor Red
    Write-Host "    สาเหตุ: $Reason" -ForegroundColor Red
    Write-Host ""
    Write-Host "  วิธีแก้:" -ForegroundColor Yellow
    foreach ($line in (Get-CutAIStepAdvice -Step $step)) { Write-Host "   - $line" -ForegroundColor Yellow }
    $report = New-CutAIFailReport -Step $step -Title $script:StepTitle -Reason $Reason
    Write-CutAIInstallLog -LogPath $script:InstallLogPath -Message "ติดตั้งล้มที่ขั้น $step/7 $($script:StepTitle): $(Protect-CutAIText $Reason)"
    Write-Host "  (บันทึกไว้ที่ไฟล์ $($script:InstallLogPath) — ส่งไฟล์นี้ให้แอดมินทางไลน์ได้)" -ForegroundColor DarkGray
    if (-not $env:CUTAI_NO_REPORT -and -not $env:CUTAI_INSTALL_TEST_FUNCS -and [Environment]::UserInteractive) {
        try {
            Write-Host ""
            Write-Host "  ส่งรายงานอาการให้ทีมงานช่วยดู? ข้อความที่จะส่งมีแค่นี้ (ไม่มีคีย์ ชื่อ หรือรหัสผ่านของคุณ):" -ForegroundColor Cyan
            Write-Host "  ------------------------------------------------"
            Write-Host $report
            Write-Host "  ------------------------------------------------"
            $ans = Read-Host "  พิมพ์ Y แล้วกด Enter เพื่อส่ง (หรือกด Enter เฉย ๆ เพื่อข้าม)"
            if ($ans -match '^\s*[yY]') {
                $contact = Read-Host "  อยากให้ติดต่อกลับทางไหน? พิมพ์ไลน์ไอดีหรือเบอร์โทร (ไม่พิมพ์ก็ได้ กด Enter ข้าม)"
                $res = Send-CutAIInstallReport -Text $report -Contact $contact -Step $step
                if ($res.Ok) { Write-Host "  [OK] ส่งรายงานให้ทีมงานแล้ว (เลขอ้างอิง $($res.Id)) — ทีมงานจะตอบกลับทางช่องทางที่คุณให้ไว้" -ForegroundColor Green }
                else { Write-Host "  [!]  ส่งรายงานไม่สำเร็จ ($($res.Reason)) — ส่งไฟล์ $($script:InstallLogPath) ให้แอดมินทางไลน์แทนได้" -ForegroundColor Yellow }
            }
        } catch { }
    }
    if (-not $NoExit) { exit 1 }
}

# $env:CUTAI_INSTALL_TEST_FUNCS=1 ให้ tests/test_install_windows.ps1 dot-source ไฟล์นี้แล้วเรียกฟังก์ชันข้างบนตรง ๆ
# โดยไม่รันขั้นตอนติดตั้งจริง — ตัวแปรนี้จะไม่ถูกตั้งบนเครื่องลูกค้า จึงไม่กระทบของจริง
if (-not $env:CUTAI_INSTALL_TEST_FUNCS) {
try {                                               # ข้อผิดพลาดที่ไม่คาดคิดก็บอกขั้น + วิธีแก้ + ถามส่งรายงานเหมือนกัน (เดิมขึ้นตัวแดงภาษาอังกฤษแล้วจบ)

Write-Host "โปรแกรมตัดคลิป AI — ตัวติดตั้งสำหรับ Windows" -ForegroundColor White

# ───────── 1) วิเคราะห์เครื่อง ─────────
Say "1/7 วิเคราะห์เครื่อง"
$os   = Get-CimInstance Win32_OperatingSystem
$cpu  = (Get-CimInstance Win32_Processor | Select-Object -First 1).Name
$ram  = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
$gpus = @(Get-CimInstance Win32_VideoController | ForEach-Object { $_.Name })
$free = [math]::Round((Get-PSDrive ($env:USERPROFILE.Substring(0,1))).Free / 1GB, 0)
Write-Host "  Windows : $($os.Caption) ($($os.Version))"
Write-Host "  CPU     : $cpu"
Write-Host "  RAM     : $ram GB"
Write-Host "  การ์ดจอ : $($gpus -join ' / ')"
Write-Host "  ดิสก์ว่าง: $free GB"
$gpuKind = "ไม่มีการ์ดจอที่ช่วยเข้ารหัสวิดีโอ — ใช้ CPU (ช้ากว่า Mac ประมาณ 2-3 เท่า แต่ใช้ได้)"
if ($gpus -match "NVIDIA")           { $gpuKind = "NVIDIA — เข้ารหัสวิดีโอด้วยการ์ดจอ (nvenc) เร็ว" }
elseif ($gpus -match "Radeon|AMD")   { $gpuKind = "AMD — เข้ารหัสวิดีโอด้วยการ์ดจอ (amf)" }
elseif ($gpus -match "Intel")        { $gpuKind = "Intel — เข้ารหัสวิดีโอด้วยชิปกราฟิก (qsv)" }
Write-Host "  คาดว่า  : $gpuKind"
if ($ram -lt 8)   { Warn "RAM น้อยกว่า 8 GB — ตัดฟุตยาว ๆ อาจช้า" }
if ($free -lt 30) { Warn "ดิสก์ว่างน้อยกว่า 30 GB — โปรแกรมเก็บไฟล์ชั่วคราวของฟุตไว้ ควรมีพื้นที่ว่างเยอะ ๆ" }

if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    Fail "ไม่พบ winget — เปิด Microsoft Store ค้นหา 'App Installer' กดติดตั้ง/อัปเดต แล้วรันไฟล์นี้ใหม่"
}

# ───────── 2) เครื่องมือ ─────────
if ($Customer) { Say "2/7 ติดตั้งเครื่องมือ (Python / FFmpeg) — ครั้งแรกใช้เวลาหลายนาที" }
else { Say "2/7 ติดตั้งเครื่องมือ (Git / Python / FFmpeg) — ครั้งแรกใช้เวลาหลายนาที" }
Refresh-Path
$git = ""
if (-not $Customer) {                              # ลูกค้าไม่ใช้ Git (โหลดโปรแกรมจากระบบขาย)
    $git = (Get-Command git -ErrorAction SilentlyContinue).Source
    if (-not $git) { Winget-Install "Git.Git" @(); $git = (Get-Command git -ErrorAction SilentlyContinue).Source }
    if (-not $git -and (Test-Path "C:\Program Files\Git\cmd\git.exe")) { $git = "C:\Program Files\Git\cmd\git.exe" }
    if (-not $git) { Fail "ติดตั้ง Git ไม่สำเร็จ — ลองรันไฟล์นี้ใหม่อีกครั้ง" }
    Ok "Git: $git"
}

function Find-Python {
    foreach ($v in "313", "312", "311", "310") {
        $p = Join-Path $env:LOCALAPPDATA "Programs\Python\Python$v\python.exe"
        if (Test-Path $p) { return $p }
        $p = "C:\Program Files\Python$v\python.exe"
        if (Test-Path $p) { return $p }
    }
    return $null                                   # ไม่ใช้ "python" เฉย ๆ — Windows มีตัวหลอกที่เปิด Microsoft Store
}
$py = Find-Python
if (-not $py) { Winget-Install "Python.Python.3.12" @("--scope", "user"); $py = Find-Python }
if (-not $py) { Fail "ติดตั้ง Python ไม่สำเร็จ — ลองรันไฟล์นี้ใหม่อีกครั้ง" }
Ok "Python: $py"

$ff = (Get-Command ffmpeg -ErrorAction SilentlyContinue).Source
if (-not $ff) { Winget-Install "Gyan.FFmpeg" @(); $ff = (Get-Command ffmpeg -ErrorAction SilentlyContinue).Source }
if (-not $ff) { Fail "ติดตั้ง FFmpeg ไม่สำเร็จ — ลองรันไฟล์นี้ใหม่อีกครั้ง" }
Ok "FFmpeg: $ff"

# ───────── 3) ดึงโปรแกรม ─────────
$ManifestUrl = ""
if ($Customer) {
    Say "3/7 ดาวน์โหลดโปรแกรมรุ่นล่าสุด"
    $sep = "?"
    if ($CutAIServer.Contains("?")) { $sep = "&" }
    if ($CutAIKey -ne "") { $ManifestUrl = $CutAIServer + $sep + "action=manifest&key=" + [uri]::EscapeDataString($CutAIKey) + "&m=installer" }
    else { $ManifestUrl = $CutAIServer + $sep + "action=manifest_public&m=installer" }
    $manifestResult = Get-CutAIManifest -ManifestUrl $ManifestUrl
    if (-not $manifestResult.Ok) {
        Fail "ติดต่อระบบขายไม่ได้ — สาเหตุ: $($manifestResult.Reason) (ลองแล้ว 3 ครั้ง + curl สำรอง)`n  แนะนำ: ลองรันไฟล์นี้ใหม่ / ปิด VPN หรือโปรแกรมแอนตี้ไวรัสชั่วคราวแล้วรันไฟล์นี้ใหม่ / ส่งรหัส error ด้านบนหรือไฟล์ log ที่ $($manifestResult.LogPath) ให้แอดมินทางไลน์"
    }
    $man = $manifestResult.Manifest
    if (-not $man.url -or -not $man.sha256) {
        $why = "ไม่พบไฟล์โปรแกรม"
        if ($man.error) { $why = $man.error }
        Fail "ดาวน์โหลดโปรแกรมไม่ได้: $why"
    }
    $zip = Join-Path $env:TEMP ("CutAI-" + $man.version_count + ".zip")
    Write-Host "  กำลังดาวน์โหลดรุ่น $($man.version_count) ($([math]::Round([double]$man.size / 1MB, 1)) MB)…"
    try { Invoke-WebRequest -Uri $man.url -OutFile $zip -UseBasicParsing -TimeoutSec 900 }
    catch { Fail "ดาวน์โหลดโปรแกรมไม่สำเร็จ — ลองรันไฟล์นี้ใหม่" }
    $h = (Get-FileHash -Algorithm SHA256 -Path $zip).Hash.ToLower()
    if ($h -ne ([string]$man.sha256).ToLower()) {
        Remove-Item $zip -ErrorAction SilentlyContinue
        Fail "ไฟล์โปรแกรมที่ดาวน์โหลดไม่ครบ/เสีย (ตรวจ sha256 ไม่ผ่าน) — รันไฟล์นี้ใหม่"
    }
    Ok "ดาวน์โหลดครบ ตรวจความถูกต้องแล้ว"
    $tmpx = Join-Path $env:TEMP ("CutAI_x_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
    Expand-Archive -Path $zip -DestinationPath $tmpx -Force
    $srcDir = Join-Path $tmpx "CutAI"
    if (-not (Test-Path (Join-Path $srcDir "launcher.py"))) { Fail "แพ็กเกจโปรแกรมไม่ครบ — รันไฟล์นี้ใหม่" }
    if (Test-Path (Join-Path $Dest ".git")) { Fail "เครื่องนี้มีโปรแกรมแบบเจ้าของ (GitHub) อยู่แล้วที่ $Dest — ไม่ติดตั้งทับ" }
    if (Test-Path $Dest) {                         # ติดตั้งซ้ำ/ซ่อม: เก็บรุ่นเดิมไว้ 1 ชุด (ข้อมูลผู้ใช้อยู่อีกโฟลเดอร์ ไม่โดนแตะ)
        $prev = $Dest + "_ก่อนหน้า"
        if (Test-Path $prev) { Remove-Item $prev -Recurse -Force -ErrorAction SilentlyContinue }
        Rename-Item $Dest (Split-Path $prev -Leaf)
    }
    Move-Item $srcDir $Dest
    Remove-Item $tmpx -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item $zip -ErrorAction SilentlyContinue
    Ok "โปรแกรมรุ่น $($man.version_count) อยู่ที่ $Dest"
} else {
Say "3/7 ดึงโปรแกรมจาก GitHub (สาย $Branch)"
Write-Host "  ถ้ามีหน้าต่างให้ล็อกอิน GitHub — กด Sign in with your browser แล้วล็อกอินบัญชีที่เป็นเจ้าของโปรแกรม" -ForegroundColor Yellow
if (Test-Path (Join-Path $Dest ".git")) {
    & $git -C $Dest fetch origin $Branch
    if ($LASTEXITCODE -ne 0) { Fail "ดึงโปรแกรมไม่สำเร็จ (เช็คอินเทอร์เน็ต / สิทธิ์ GitHub)" }
    & $git -C $Dest checkout -B $Branch "origin/$Branch"
    & $git -C $Dest reset --hard "origin/$Branch"
} else {
    if (Test-Path $Dest) { Rename-Item $Dest ("CutAI_old_" + (Get-Date -Format "yyyyMMdd_HHmmss")) }
    & $git clone --branch $Branch $Repo $Dest
    if ($LASTEXITCODE -ne 0) { Fail "ดึงโปรแกรมไม่สำเร็จ (เช็คอินเทอร์เน็ต / สิทธิ์ GitHub)" }
}
Ok "โปรแกรมอยู่ที่ $Dest"
}

# ───────── 4) ไลบรารี Python ─────────
Say "4/7 ติดตั้งไลบรารี Python (ตัวถอดเสียงสำรองค่อนข้างใหญ่ รอสักครู่)"
$env:PYTHONUTF8 = "1"
& $py -m pip install --disable-pip-version-check -q --upgrade pip
& $py -m pip install --disable-pip-version-check -r (Join-Path $Dest "requirements.txt")
if ($LASTEXITCODE -ne 0) { Warn "ติดตั้งไลบรารีบางตัวไม่สำเร็จ — โปรแกรมจะบอกในหน้าตรวจเครื่อง" } else { Ok "ไลบรารีครบ" }

# โหลดตัวถอดเสียงในเครื่องไว้ก่อน — ไม่งั้นงานแรกที่ไม่มีคีย์ ElevenLabs จะค้างเงียบ ๆ ระหว่างโหลด 1.5 GB (ผู้ใช้นึกว่าโปรแกรมแฮงค์)
# - เขียนโค้ด python ลงไฟล์ชั่วคราวแทน -c "..." เพราะ PowerShell 5.1 ส่งเครื่องหมายคำพูดให้โปรแกรมอื่นเพี้ยน
# - ในโค้ดย้าย stderr ไป stdout (แถบความคืบหน้าอยู่ทาง stderr — PowerShell บางโหมดนับเป็น error แล้วหยุดทั้งสคริปต์)
# - โหลดไม่สำเร็จไม่ใช่เรื่องใหญ่ (โปรแกรมโหลดเองตอนใช้ครั้งแรก) จึงห่อ try ไว้ ไม่ให้ตัวติดตั้งล้มทั้งตัว
Write-Host "  กำลังดาวน์โหลดตัวถอดเสียงในเครื่อง (~1.5 GB) ครั้งเดียว… มีแถบความคืบหน้า รอจนเสร็จ (เน็ตช้าอาจ 10-30 นาที)" -ForegroundColor Yellow
$env:HF_HUB_DISABLE_SYMLINKS_WARNING = "1"
$preload = Join-Path $env:TEMP "cutai_preload_whisper.py"
$preCode = 1
try {
    @'
import os, sys
os.dup2(1, 2)
sys.stderr = sys.stdout
try:
    from faster_whisper import WhisperModel
except Exception as e:
    print("faster_whisper import failed:", e)
    sys.exit(3)
WhisperModel("large-v3-turbo", device="cpu", compute_type="int8")
print("OK")
'@ | Set-Content -Path $preload -Encoding ASCII
    & $py $preload
    $preCode = $LASTEXITCODE
} catch {
    $preCode = 1
}
Remove-Item $preload -ErrorAction SilentlyContinue
if ($preCode -eq 3)     { Warn "ไม่พบ faster_whisper — ข้ามการโหลดตัวถอดเสียงในเครื่อง (ใช้ตัวถอดเสียงออนไลน์ ElevenLabs ได้ตามปกติ)" }
elseif ($preCode -ne 0) { Warn "โหลดตัวถอดเสียงในเครื่องไม่สำเร็จ — ไม่เป็นไร โปรแกรมจะโหลดเองตอนใช้ครั้งแรก (หรือรันตัวติดตั้งนี้ใหม่)" }
else                    { Ok "ตัวถอดเสียงในเครื่องพร้อมใช้ (large-v3-turbo)" }

# ───────── 5) ตรวจเครื่องมือ ─────────
Say "5/7 ตรวจเครื่องมือของโปรแกรม + เลือกตัวเข้ารหัสวิดีโอ"
$env:PYTHONIOENCODING = "utf-8"
Push-Location $Dest
& $py (Join-Path $Dest "config.py")
Pop-Location
# โฟลเดอร์ข้อมูล — กติกาเดียวกับ plat.data_dir: เครื่องที่เคยติดตั้งใช้ CutAI\งาน ต่อ · เครื่องใหม่แยกไว้ต่อผู้ใช้
# (ห้ามสร้าง CutAI\งาน บนเครื่องใหม่ ไม่งั้นโปรแกรมจะไปใช้ที่นั่นแทน แล้วคีย์/ค่าที่ตรวจไว้ตอนติดตั้งจะอยู่คนละที่)
if ($env:CUTAI_DATA) { $DataDir = $env:CUTAI_DATA }
elseif (Test-Path -PathType Container (Join-Path $Dest "งาน")) { $DataDir = Join-Path $Dest "งาน" }
else { $DataDir = Join-Path $env:LOCALAPPDATA "CutAI\งาน" }
$report = Join-Path $DataDir "เครื่องนี้.txt"
New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
@(
    "ติดตั้งเมื่อ: $(Get-Date -Format 'yyyy-MM-dd HH:mm')",
    "Windows: $($os.Caption) ($($os.Version))", "CPU: $cpu", "RAM: $ram GB",
    "การ์ดจอ: $($gpus -join ' / ')", "ดิสก์ว่าง: $free GB",
    "Python: $py", "FFmpeg: $ff", "Git: $git"
) | Set-Content -Path $report -Encoding UTF8
if ($Customer) {                                   # จดคีย์ + ช่องทางอัปเดต → โปรแกรมเปิดใช้งานเองตอนเปิดครั้งแรก (licensing.py)
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    if ($CutAIKey -ne "") { [IO.File]::WriteAllText((Join-Path $DataDir "ใบอนุญาต.json"), (@{ key = $CutAIKey } | ConvertTo-Json), $utf8) }
    [IO.File]::WriteAllText((Join-Path $DataDir "update_channel.json"), (@{ channel = "zip"; manifest_url = $ManifestUrl } | ConvertTo-Json), $utf8)
    if ($CutAIKey -ne "") { Ok "จดคีย์ไว้แล้ว — โปรแกรมจะเปิดใช้งานเองตอนเปิดครั้งแรก (ต้องต่ออินเทอร์เน็ต)" }
    else { Ok "ตั้งช่องทางอัปเดตแล้ว — เปิดโปรแกรมแล้วขอคีย์ใช้ฟรีได้เลย" }
}

# ───────── 6) ไอคอน ─────────
Say "6/7 สร้างไอคอนบน Desktop"
$pyw = Join-Path (Split-Path $py) "pythonw.exe"
if (-not (Test-Path $pyw)) { $pyw = $py }
$desk = [Environment]::GetFolderPath("Desktop")
if ($env:CUTAI_DESKTOP) { $desk = $env:CUTAI_DESKTOP; New-Item -ItemType Directory -Force -Path $desk | Out-Null }
# WScript.Shell บันทึกชื่อไฟล์ด้วยภาษาของระบบ (ANSI) — เครื่องที่ไม่ได้ตั้งภาษาไทย ชื่อไทยกลายเป็น ??? แล้วบันทึกไม่ได้
# → บันทึกเป็นชื่ออังกฤษก่อน แล้วค่อยเปลี่ยนชื่อเป็นไทยด้วย PowerShell (รองรับ Unicode) · พลาดก็ไม่หยุดติดตั้ง
try {
    $ws = New-Object -ComObject WScript.Shell
    $tmpLnk = Join-Path $desk "CutAI-shortcut.lnk"
    $lnk = $ws.CreateShortcut($tmpLnk)
    $lnk.TargetPath = $pyw
    $lnk.Arguments = "`"$Dest\launcher.py`""
    $lnk.WorkingDirectory = $Dest
    $lnk.IconLocation = "$env:SystemRoot\System32\imageres.dll,18"
    $lnk.Description = "CutAI"
    $lnk.Save()
    $final = Join-Path $desk "ตัดคลิป AI.lnk"
    if (Test-Path -LiteralPath $final) { Remove-Item -LiteralPath $final -Force -ErrorAction SilentlyContinue }
    try { Rename-Item -LiteralPath $tmpLnk -NewName "ตัดคลิป AI.lnk" -ErrorAction Stop; Ok "ไอคอน 'ตัดคลิป AI' อยู่บน Desktop แล้ว" }
    catch { Ok "ไอคอน 'CutAI-shortcut' อยู่บน Desktop แล้ว (ตั้งชื่อไทยไม่ได้ ใช้ชื่อนี้แทน)" }
} catch {
    Write-Host "  [!] สร้างไอคอนบน Desktop ไม่ได้ — โปรแกรมติดตั้งเสร็จแล้ว เปิดได้จาก $Dest\launcher.py" -ForegroundColor Yellow
}

# ───────── 7) เปิดโปรแกรม ─────────
Say "7/7 เปิดโปรแกรม"
Start-Process -FilePath $pyw -ArgumentList "`"$Dest\launcher.py`"" -WorkingDirectory $Dest
if ($Customer) { $null = Send-CutAIInstallDone }   # ครบ 7 ขั้นแล้วเท่านั้น · ยิงไม่ติดก็จบปกติ
Write-Host ""
Write-Host "เสร็จแล้ว! หน้าโปรแกรมจะเปิดในเบราว์เซอร์ให้เอง (ปกติ http://127.0.0.1:8765)" -ForegroundColor Green
Write-Host "ครั้งแรก: ทำการ์ด 'ตั้งค่าครั้งแรก' บนหน้าแรก (ใส่คีย์ Google AI ฟรี)" -ForegroundColor Green
Write-Host "ต่อไปเปิดจากไอคอน 'ตัดคลิป AI' บน Desktop — โปรแกรมจะอัปเดตตัวเองทุกครั้งที่เปิด"
Write-Host "ข้อมูลของโปรแกรม (คีย์/ตั้งค่า/บันทึกการทำงาน) อยู่ที่ $DataDir"

} catch {
    Stop-CutAIInstall -Reason ("เกิดข้อผิดพลาดที่ไม่คาดคิด: " + (Get-CutAIErrorReason -Exception $_.Exception))
}
}
